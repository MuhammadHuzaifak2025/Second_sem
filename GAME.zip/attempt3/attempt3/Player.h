#ifndef PLAYER_H
#define PLAYER_H
#include"mainwindow.h"
#include <QDialog>

namespace Ui {
class Player;
}

class player : public QDialog, public Person
{
    Q_OBJECT
    long int score;
    QString Acheivement;

public:
    int get_score(){
        return score;
    }
    QString get_Acheivement(){
        return Acheivement;
    }
    void cal_score(int a){
        score += a;
    }
    void set_acheivement(QString A){
        Acheivement = A;
    }
    explicit player(QWidget *parent = nullptr);
    ~player();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Player *ui;
};

#endif // PLAYER_H
