/********************************************************************************
** Form generated from reading UI file 'menu.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MENU_H
#define UI_MENU_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolButton>

QT_BEGIN_NAMESPACE

class Ui_menu
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QToolButton *toolButton;
    QToolButton *Setting;
    QToolButton *LeaderBoard;
    QLabel *label_4;
    QPlainTextEdit *plainTextEdit;
    QPlainTextEdit *plainTextEdit_2;
    QLabel *label_5;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPlainTextEdit *plainTextEdit_3;
    QLabel *label_6;
    QTextEdit *textEdit;
    QLineEdit *User_name;
    QTextEdit *textEdit_2;
    QLineEdit *lineEdit_2;
    QTextEdit *textEdit_3;
    QLineEdit *lineEdit_3;
    QTextEdit *textEdit_4;
    QLineEdit *lineEdit_4;
    QTextEdit *textEdit_5;
    QLineEdit *lineEdit_5;
    QLabel *screen2b;
    QPlainTextEdit *editprofile;
    QPlainTextEdit *editname;
    QPlainTextEdit *editage;
    QPlainTextEdit *editpassword;
    QLineEdit *passinput;
    QLineEdit *ageinput;
    QLineEdit *nameinput;
    QLabel *screen2a;
    QToolButton *Settings2;
    QToolButton *Home2;
    QToolButton *noti2;

    void setupUi(QDialog *menu)
    {
        if (menu->objectName().isEmpty())
            menu->setObjectName("menu");
        menu->resize(1280, 720);
        label = new QLabel(menu);
        label->setObjectName("label");
        label->setGeometry(QRect(0, 0, 381, 720));
        label->setStyleSheet(QString::fromUtf8("background: #1E1F2E;"));
        label_2 = new QLabel(menu);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(100, 90, 190, 165));
        label_2->setStyleSheet(QString::fromUtf8("\n"
"\n"
"background: url(\"D:/OOP_Project/attempt3/attempt3/images/pfp.png\");"));
        label_3 = new QLabel(menu);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(381, 0, 899, 199));
        label_3->setStyleSheet(QString::fromUtf8("background: #252748;"));
        toolButton = new QToolButton(menu);
        toolButton->setObjectName("toolButton");
        toolButton->setGeometry(QRect(420, 60, 312, 91));
        QFont font;
        font.setFamilies({QString::fromUtf8("Arial Black")});
        font.setBold(false);
        font.setUnderline(true);
        toolButton->setFont(font);
        toolButton->setStyleSheet(QString::fromUtf8("color:#FFF;\n"
"border: none;\n"
"font-size: 55px;"));
        Setting = new QToolButton(menu);
        Setting->setObjectName("Setting");
        Setting->setGeometry(QRect(740, 90, 211, 41));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Arial Black")});
        font1.setBold(true);
        font1.setItalic(false);
        font1.setUnderline(true);
        Setting->setFont(font1);
        Setting->setStyleSheet(QString::fromUtf8("font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 35px;\n"
"line-height: 42px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"color:#FFF;\n"
"border: none;"));
        LeaderBoard = new QToolButton(menu);
        LeaderBoard->setObjectName("LeaderBoard");
        LeaderBoard->setGeometry(QRect(1000, 90, 261, 42));
        QFont font2;
        font2.setFamilies({QString::fromUtf8("Inter")});
        font2.setBold(true);
        font2.setItalic(false);
        font2.setUnderline(true);
        LeaderBoard->setFont(font2);
        LeaderBoard->setStyleSheet(QString::fromUtf8("font-family: 'Inter';\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 35px;\n"
"line-height: 42px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"border: none;\n"
"color: #FFFFFF;"));
        label_4 = new QLabel(menu);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(380, 200, 899, 521));
        label_4->setStyleSheet(QString::fromUtf8("background: #f0f0f0;"));
        plainTextEdit = new QPlainTextEdit(menu);
        plainTextEdit->setObjectName("plainTextEdit");
        plainTextEdit->setGeometry(QRect(430, 240, 241, 91));
        QFont font3;
        font3.setFamilies({QString::fromUtf8("Inter")});
        font3.setBold(true);
        font3.setItalic(false);
        plainTextEdit->setFont(font3);
        plainTextEdit->setStyleSheet(QString::fromUtf8("font-family: 'Inter';\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 54px;\n"
"line-height: 65px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"border:none;\n"
"color: #252748;\n"
"background: #f0f0f0;"));
        plainTextEdit_2 = new QPlainTextEdit(menu);
        plainTextEdit_2->setObjectName("plainTextEdit_2");
        plainTextEdit_2->setGeometry(QRect(450, 340, 321, 71));
        plainTextEdit_2->setStyleSheet(QString::fromUtf8("font-family: 'Inter';\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 40px;\n"
"line-height: 48px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"border: none;\n"
"color: #000000;\n"
"background: #f0f0f0\n"
""));
        label_5 = new QLabel(menu);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(450, 430, 324, 208));
        label_5->setStyleSheet(QString::fromUtf8("background: url(\"D:/Qt Projects/attempt3/images/snake.png\")"));
        pushButton = new QPushButton(menu);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(450, 650, 326, 54));
        pushButton->setFont(font3);
        pushButton->setStyleSheet(QString::fromUtf8("background: #BB5858;\n"
"font-family: 'Inter';\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 40px;\n"
"line-height: 48px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"\n"
"color: #FFFFFF;"));
        pushButton_2 = new QPushButton(menu);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setGeometry(QRect(850, 650, 326, 54));
        pushButton_2->setFont(font3);
        pushButton_2->setStyleSheet(QString::fromUtf8("background: #BB5858;\n"
"font-family: 'Inter';\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 40px;\n"
"line-height: 48px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"\n"
"color: #FFFFFF;"));
        plainTextEdit_3 = new QPlainTextEdit(menu);
        plainTextEdit_3->setObjectName("plainTextEdit_3");
        plainTextEdit_3->setGeometry(QRect(850, 340, 301, 71));
        plainTextEdit_3->setStyleSheet(QString::fromUtf8("font-family: 'Inter';\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 40px;\n"
"line-height: 48px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"border: none;\n"
"color: #000000;\n"
"background: #f0f0f0\n"
""));
        label_6 = new QLabel(menu);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(850, 430, 324, 208));
        label_6->setStyleSheet(QString::fromUtf8("background: url(\"D:/Qt Projects/attempt3/images/fp.png\")"));
        textEdit = new QTextEdit(menu);
        textEdit->setObjectName("textEdit");
        textEdit->setGeometry(QRect(10, 280, 211, 61));
        textEdit->setFont(font3);
        textEdit->setStyleSheet(QString::fromUtf8("border: none;\n"
"font-family: 'Inter';\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 40px;\n"
"line-height: 48px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"background: #1E1F2E;\n"
"color: #FFFFFF;"));
        User_name = new QLineEdit(menu);
        User_name->setObjectName("User_name");
        User_name->setGeometry(QRect(200, 280, 171, 61));
        User_name->setStyleSheet(QString::fromUtf8("border: none;\n"
"font-family: 'Inter';\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 40px;\n"
"line-height: 48px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"background: #1E1F2E;\n"
"color: #FFFFFF;"));
        textEdit_2 = new QTextEdit(menu);
        textEdit_2->setObjectName("textEdit_2");
        textEdit_2->setGeometry(QRect(10, 360, 141, 61));
        textEdit_2->setFont(font3);
        textEdit_2->setStyleSheet(QString::fromUtf8("font-family: 'Inter';\n"
"border:none;\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 40px;\n"
"line-height: 48px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"background: #1E1F2E;\n"
"color: #FFFFFF;"));
        lineEdit_2 = new QLineEdit(menu);
        lineEdit_2->setObjectName("lineEdit_2");
        lineEdit_2->setGeometry(QRect(130, 360, 241, 61));
        lineEdit_2->setStyleSheet(QString::fromUtf8("border: none;\n"
"font-family: 'Inter';\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 40px;\n"
"line-height: 48px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"background: #1E1F2E;\n"
"color: #FFFFFF;"));
        textEdit_3 = new QTextEdit(menu);
        textEdit_3->setObjectName("textEdit_3");
        textEdit_3->setGeometry(QRect(10, 440, 141, 61));
        textEdit_3->setFont(font3);
        textEdit_3->setStyleSheet(QString::fromUtf8("font-family: 'Inter';\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 40px;\n"
"line-height: 48px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"background: #1E1F2E;\n"
"color: #FFFFFF;\n"
"border:none;"));
        lineEdit_3 = new QLineEdit(menu);
        lineEdit_3->setObjectName("lineEdit_3");
        lineEdit_3->setGeometry(QRect(140, 440, 231, 61));
        lineEdit_3->setStyleSheet(QString::fromUtf8("border: none;\n"
"font-family: 'Inter';\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 40px;\n"
"line-height: 48px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"background: #1E1F2E;\n"
"color: #FFFFFF;"));
        textEdit_4 = new QTextEdit(menu);
        textEdit_4->setObjectName("textEdit_4");
        textEdit_4->setGeometry(QRect(10, 520, 251, 61));
        textEdit_4->setFont(font3);
        textEdit_4->setStyleSheet(QString::fromUtf8("font-family: 'Inter';\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 40px;\n"
"line-height: 48px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"background: #1E1F2E;\n"
"color: #FFFFFF;\n"
"border:none;"));
        lineEdit_4 = new QLineEdit(menu);
        lineEdit_4->setObjectName("lineEdit_4");
        lineEdit_4->setGeometry(QRect(0, 590, 371, 41));
        lineEdit_4->setStyleSheet(QString::fromUtf8("border: none;\n"
"font-family: 'Inter';\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 40px;\n"
"line-height: 48px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"background: #1E1F2E;\n"
"color: #FFFFFF;"));
        textEdit_5 = new QTextEdit(menu);
        textEdit_5->setObjectName("textEdit_5");
        textEdit_5->setGeometry(QRect(10, 640, 151, 61));
        textEdit_5->setFont(font3);
        textEdit_5->setStyleSheet(QString::fromUtf8("font-family: 'Inter';\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 40px;\n"
"line-height: 48px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"background: #1E1F2E;\n"
"color: #FFFFFF;\n"
"border:none;"));
        lineEdit_5 = new QLineEdit(menu);
        lineEdit_5->setObjectName("lineEdit_5");
        lineEdit_5->setGeometry(QRect(140, 640, 231, 61));
        lineEdit_5->setStyleSheet(QString::fromUtf8("border: none;\n"
"font-family: 'Inter';\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 40px;\n"
"line-height: 48px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"background: #1E1F2E;\n"
"color: #FFFFFF;"));
        screen2b = new QLabel(menu);
        screen2b->setObjectName("screen2b");
        screen2b->setGeometry(QRect(380, 200, 899, 521));
        screen2b->setStyleSheet(QString::fromUtf8("background: #f0f0f0"));
        editprofile = new QPlainTextEdit(menu);
        editprofile->setObjectName("editprofile");
        editprofile->setGeometry(QRect(410, 220, 341, 91));
        editprofile->setStyleSheet(QString::fromUtf8("font-family: 'Inter';\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 54px;\n"
"line-height: 65px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"\n"
"color: #252748;\n"
"background: #f0f0f0;\n"
"border:none;\n"
""));
        editname = new QPlainTextEdit(menu);
        editname->setObjectName("editname");
        editname->setGeometry(QRect(460, 340, 261, 71));
        editname->setStyleSheet(QString::fromUtf8("font-family: 'Inter';\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 40px;\n"
"line-height: 48px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"\n"
"color: #252748;\n"
"background: #f0f0f0;\n"
"border:none;"));
        editage = new QPlainTextEdit(menu);
        editage->setObjectName("editage");
        editage->setGeometry(QRect(460, 440, 221, 71));
        editage->setStyleSheet(QString::fromUtf8("font-family: 'Inter';\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 40px;\n"
"line-height: 48px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"\n"
"color: #252748;\n"
"background: #f0f0f0;\n"
"border:none;"));
        editpassword = new QPlainTextEdit(menu);
        editpassword->setObjectName("editpassword");
        editpassword->setGeometry(QRect(460, 540, 341, 71));
        editpassword->setStyleSheet(QString::fromUtf8("font-family: 'Inter';\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 40px;\n"
"line-height: 48px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"\n"
"color: #252748;\n"
"background: #f0f0f0;\n"
"border:none;"));
        passinput = new QLineEdit(menu);
        passinput->setObjectName("passinput");
        passinput->setGeometry(QRect(830, 550, 397, 61));
        passinput->setStyleSheet(QString::fromUtf8("position: absolute;\n"
"width: 397px;\n"
"height: 40px;\n"
"left: 799px;\n"
"top: 358px;\n"
"\n"
"background: #252748;\n"
"opacity: 0.85;\n"
"border-radius: 30px;"));
        ageinput = new QLineEdit(menu);
        ageinput->setObjectName("ageinput");
        ageinput->setGeometry(QRect(830, 450, 397, 61));
        ageinput->setStyleSheet(QString::fromUtf8("position: absolute;\n"
"width: 397px;\n"
"height: 40px;\n"
"left: 799px;\n"
"top: 358px;\n"
"\n"
"background: #252748;\n"
"opacity: 0.85;\n"
"border: 2px solid;\n"
"border-radius: 30px;"));
        nameinput = new QLineEdit(menu);
        nameinput->setObjectName("nameinput");
        nameinput->setGeometry(QRect(830, 350, 397, 61));
        nameinput->setStyleSheet(QString::fromUtf8("background: #252748;\n"
"border-radius: 30px;"));
        screen2a = new QLabel(menu);
        screen2a->setObjectName("screen2a");
        screen2a->setGeometry(QRect(380, 0, 899, 199));
        screen2a->setStyleSheet(QString::fromUtf8("background: #252748;"));
        Settings2 = new QToolButton(menu);
        Settings2->setObjectName("Settings2");
        Settings2->setGeometry(QRect(410, 50, 312, 91));
        Settings2->setFont(font2);
        Settings2->setStyleSheet(QString::fromUtf8("font-family: 'Inter';\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 55px;\n"
"line-height: 82px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"text-decoration-line: underline;\n"
"border: none;\n"
"color: #FFFFFF;"));
        Home2 = new QToolButton(menu);
        Home2->setObjectName("Home2");
        Home2->setGeometry(QRect(740, 80, 211, 41));
        Home2->setFont(font1);
        Home2->setStyleSheet(QString::fromUtf8("font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 35px;\n"
"line-height: 42px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"color:#FFF;\n"
"border: none;"));
        noti2 = new QToolButton(menu);
        noti2->setObjectName("noti2");
        noti2->setGeometry(QRect(960, 80, 281, 42));
        noti2->setFont(font2);
        noti2->setStyleSheet(QString::fromUtf8("font-family: 'Inter';\n"
"font-style: normal;\n"
"font-weight: 900;\n"
"font-size: 35px;\n"
"line-height: 42px;\n"
"display: flex;\n"
"align-items: center;\n"
"text-align: center;\n"
"border: none;\n"
"color: #FFFFFF;"));
        screen2b->raise();
        editage->raise();
        editpassword->raise();
        ageinput->raise();
        nameinput->raise();
        passinput->raise();
        editname->raise();
        editprofile->raise();
        screen2a->raise();
        Settings2->raise();
        Home2->raise();
        noti2->raise();
        label->raise();
        label_2->raise();
        label_3->raise();
        toolButton->raise();
        Setting->raise();
        LeaderBoard->raise();
        label_4->raise();
        plainTextEdit->raise();
        plainTextEdit_2->raise();
        label_5->raise();
        pushButton->raise();
        pushButton_2->raise();
        plainTextEdit_3->raise();
        label_6->raise();
        textEdit->raise();
        User_name->raise();
        textEdit_2->raise();
        lineEdit_2->raise();
        textEdit_3->raise();
        lineEdit_3->raise();
        textEdit_4->raise();
        lineEdit_4->raise();
        textEdit_5->raise();
        lineEdit_5->raise();

        retranslateUi(menu);

        QMetaObject::connectSlotsByName(menu);
    } // setupUi

    void retranslateUi(QDialog *menu)
    {
        menu->setWindowTitle(QCoreApplication::translate("menu", "Dialog", nullptr));
        label->setText(QString());
        label_2->setText(QString());
        label_3->setText(QString());
        toolButton->setText(QCoreApplication::translate("menu", "HOME", nullptr));
        Setting->setText(QCoreApplication::translate("menu", "SETTINGS", nullptr));
        LeaderBoard->setText(QCoreApplication::translate("menu", "Leaderboards", nullptr));
        label_4->setText(QString());
        plainTextEdit->setPlainText(QCoreApplication::translate("menu", "GAMES", nullptr));
        plainTextEdit_2->setPlainText(QCoreApplication::translate("menu", "SNAKE GAME", nullptr));
        label_5->setText(QString());
        pushButton->setText(QCoreApplication::translate("menu", "PLAY", nullptr));
        pushButton_2->setText(QCoreApplication::translate("menu", "PLAY", nullptr));
        plainTextEdit_3->setPlainText(QCoreApplication::translate("menu", "FLAPPYBIRD", nullptr));
        label_6->setText(QString());
        textEdit->setHtml(QCoreApplication::translate("menu", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Inter'; font-size:40px; font-weight:900; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Segoe UI'; font-size:28pt; font-weight:400;\">Username:</span></p></body></html>", nullptr));
        textEdit_2->setHtml(QCoreApplication::translate("menu", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Inter'; font-size:40px; font-weight:900; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Segoe UI'; font-size:28pt; font-weight:400;\">Name:</span></p></body></html>", nullptr));
        textEdit_3->setHtml(QCoreApplication::translate("menu", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Inter'; font-size:40px; font-weight:900; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Segoe UI'; font-size:28pt; font-weight:400;\">Rank#:</span></p></body></html>", nullptr));
        textEdit_4->setHtml(QCoreApplication::translate("menu", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Inter'; font-size:40px; font-weight:900; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'Segoe UI'; font-size:28pt; font-weight:400;\">Achievement:</span></p></body></html>", nullptr));
        textEdit_5->setHtml(QCoreApplication::translate("menu", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Inter'; font-size:40px; font-weight:900; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:40px; font-weight:400;\">Score: </span></p></body></html>", nullptr));
        screen2b->setText(QString());
        editprofile->setPlainText(QCoreApplication::translate("menu", "Edit Profile", nullptr));
        editname->setPlainText(QCoreApplication::translate("menu", "Edit Name:", nullptr));
        editage->setPlainText(QCoreApplication::translate("menu", "Edit Age:", nullptr));
        editpassword->setPlainText(QCoreApplication::translate("menu", "Edit Password:", nullptr));
        screen2a->setText(QString());
        Settings2->setText(QCoreApplication::translate("menu", "Settings", nullptr));
        Home2->setText(QCoreApplication::translate("menu", "Home", nullptr));
        noti2->setText(QCoreApplication::translate("menu", "Leaderboards", nullptr));
    } // retranslateUi

};

namespace Ui {
    class menu: public Ui_menu {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MENU_H
