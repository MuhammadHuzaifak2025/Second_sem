#include "menu.h"
#include "ui_menu.h"
#include <QPixmap>
#include <QMessageBox>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QDialog>
#include <QMovie>
#include <QIcon>
#include<QFile>

menu::menu(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::menu)
{
    ui->setupUi(this);


    ui->User_name->setReadOnly(true);
    ui->lineEdit_2->setReadOnly(true);
    ui->lineEdit_3->setReadOnly(true);
    ui->lineEdit_4->setReadOnly(true);
    ui->lineEdit_5->setReadOnly(true);
    ui->textEdit->setReadOnly(true);
    ui->textEdit_2->setReadOnly(true);
    ui->textEdit_3->setReadOnly(true);
    ui->textEdit_4->setReadOnly(true);
    ui->textEdit_5->setReadOnly(true);
    ui->textEdit->setReadOnly(true);
    ui->plainTextEdit->setReadOnly(true);
    ui->plainTextEdit_2->setReadOnly(true);
    ui->plainTextEdit_3->setReadOnly(true);
    ui->editage->setReadOnly(true);
    ui->editname->setReadOnly(true);
    ui->editpassword->setReadOnly(true);
    ui->editprofile->setReadOnly(true);

    QFile file1("Accounts.txt");
    file1.open(QIODevice::ReadOnly);
    QTextStream in(&file1);


    while(!in.atEnd()){

        QStringList data1;
        QString line = in.readLine();
        QStringList stringList = line.split(" ");
        data1.append(stringList);

    }
}

menu::~menu()
{
    delete ui;
}

void menu::on_toolButton_2_clicked()
{

    ui->screen2a->raise();
    ui->screen2b->raise();
    ui->Settings2->raise();
    ui->Home2->raise();
    ui->noti2->raise();
    ui->editname->raise();
    ui->editage->raise();
    ui->editpassword->raise();
    ui->editprofile->raise();
    ui->ageinput->raise();
    ui->nameinput->raise();
    ui->passinput->raise();
}



void menu::on_Home2_clicked()
{
    ui->screen2a->lower();
    ui->screen2b->lower();
    ui->Settings2->lower();
    ui->Home2->lower();
    ui->noti2->lower();
    ui->editname->lower();
    ui->editage->lower();
    ui->editpassword->lower();
    ui->editprofile->lower();
    ui->ageinput->lower();
    ui->nameinput->lower();
    ui->passinput->lower();
}

