#ifndef ADMIN_H
#define ADMIN_H
#include"mainwindow.h"
#include <QDialog>

namespace Ui {
class Admin;
}

class Admin : public QDialog, public Person
{
    Q_OBJECT

public:

    explicit Admin(QWidget *parent = nullptr);
    ~Admin();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Admin *ui;
};

#endif // ADMIN_H
